// script.js — ShopEasy functionality
(() => {
  const PRODUCTS = [
    {id:1,name:"Aurora Headphones",price:2499,category:"Electronics",desc:"Comfortable over-ear headphones with deep bass and long battery life."},
    {id:2,name:"Nimbus Jacket",price:1999,category:"Clothing",desc:"Water-resistant jacket for all-weather comfort."},
    {id:3,name:"Luna Lamp",price:899,category:"Home",desc:"Smart touch lamp with adjustable brightness and warm light."},
    {id:4,name:"BrewMaster Kettle",price:1499,category:"Home",desc:"Fast-boil electric kettle with auto shut-off."},
    {id:5,name:"Pocket Notebook",price:199,category:"Books",desc:"Pocket-sized notebook with 120 ruled pages."},
    {id:6,name:"Glow Serum",price:799,category:"Beauty",desc:"Vitamin C serum for brighter skin."},
    {id:7,name:"Comfy Sneakers",price:2999,category:"Clothing",desc:"Lightweight sneakers built for daily use."},
    {id:8,name:"PixelWatch Strap",price:349,category:"Electronics",desc:"Silicone strap compatible with most smartwatches."},
    {id:9,name:"Culinary Knife",price:1599,category:"Home",desc:"Stainless steel chef knife for home cooks."},
    {id:10,name:"Storytime",price:349,category:"Books",desc:"A collection of short inspiring tales."}
  ];

  // Utilities
  const qs = s => document.querySelector(s);
  const qsa = s => Array.from(document.querySelectorAll(s));
  const formatPrice = v => "₹" + v.toFixed(2);

  // Generate simple SVG placeholder data-uri to act as product image
  function svgDataUri(text, bg="#e6eef1") {
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='800' height='600'>
      <rect width='100%' height='100%' fill='${bg}' />
      <text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-family='Arial' font-size='36' fill='#2b3742'>${text}</text>
    </svg>`;
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }

  // State
  let state = {
    products: PRODUCTS.map(p => ({...p, image: svgDataUri(p.name)})),
    filtered: [],
    cart: loadCart() || {},
    activeCategory: 'all',
    sort: 'featured',
    search: ''
  };

  // DOM refs
  const productsGrid = qs("#products-grid");
  const searchInput = qs("#search");
  const sortSelect = qs("#sort");
  const categoryButtons = qsa(".category");
  const cartBtn = qs("#cart-btn");
  const cartEl = qs("#cart");
  const cartClose = qs("#cart-close");
  const cartItemsEl = qs("#cart-items");
  const cartCount = qs("#cart-count");
  const cartTotal = qs("#cart-total");
  const clearCartBtn = qs("#clear-cart");
  const checkoutBtn = qs("#checkout");

  const modal = qs("#product-modal");
  const modalClose = qs("#modal-close");
  const modalTitle = qs("#modal-title");
  const modalDesc = qs("#modal-desc");
  const modalImage = qs("#modal-image");
  const modalPrice = qs("#modal-price");
  const modalQty = qs("#modal-qty");
  const modalAdd = qs("#modal-add");

  // Init
  function init() {
    state.filtered = state.products.slice();
    renderProducts(state.filtered);
    attachListeners();
    renderCart();
    updateCartCount();
  }

  // Render products grid
  function renderProducts(list) {
    productsGrid.innerHTML = "";
    if(!list.length){
      productsGrid.innerHTML = "<p style='grid-column:1/-1;color:var(--muted)'>No products found.</p>";
      return;
    }
    list.forEach(p => {
      const card = document.createElement("article");
      card.className = "card";
      card.innerHTML = `
        <img src="${p.image}" alt="${p.name}" loading="lazy" />
        <div>
          <h3 style="margin:6px 0 4px 0">${p.name}</h3>
          <p style="margin:0 0 8px 0;color:var(--muted);font-size:13px">${p.category}</p>
          <div class="meta">
            <div class="price">${formatPrice(p.price)}</div>
            <button class="btn small" data-id="${p.id}" style="padding:6px 8px">View</button>
          </div>
        </div>
      `;
      const viewBtn = card.querySelector("button[data-id]");
      viewBtn.addEventListener("click", () => openModal(p.id));
      productsGrid.appendChild(card);
    });
  }

  // Attach listeners
  function attachListeners() {
    // search (debounced)
    let t;
    searchInput.addEventListener("input", e => {
      clearTimeout(t);
      t = setTimeout(() => {
        state.search = e.target.value.trim().toLowerCase();
        applyFilters();
      }, 180);
    });

    // sort
    sortSelect.addEventListener("change", e => {
      state.sort = e.target.value;
      applyFilters();
    });

    // category buttons
    categoryButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        categoryButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        state.activeCategory = btn.dataset.cat;
        applyFilters();
      });
    });

    // cart open/close
    cartBtn.addEventListener("click", () => openCart());
    cartClose.addEventListener("click", () => closeCart());
    clearCartBtn.addEventListener("click", () => { if(confirm("Clear cart?")) { state.cart = {}; saveCart(); renderCart(); updateCartCount(); }});
    checkoutBtn.addEventListener("click", handleCheckout);

    // modal
    modalClose.addEventListener("click", closeModal);
    modal.addEventListener("click", (e) => { if(e.target === modal) closeModal(); });
    modalAdd.addEventListener("click", () => {
      const id = modalAdd.dataset.id;
      const qty = Math.max(1, Number(modalQty.value) || 1);
      addToCart(Number(id), qty);
      closeModal();
      openCart();
    });

    // keyboard escape
    window.addEventListener("keydown", (e) => {
      if(e.key === "Escape") { closeModal(); closeCart(); }
    });
  }

  function applyFilters() {
    let list = state.products.slice();
    if(state.activeCategory !== 'all'){
      list = list.filter(p => p.category === state.activeCategory);
    }
    if(state.search){
      const s = state.search;
      list = list.filter(p => (p.name + " " + p.desc + " " + p.category).toLowerCase().includes(s));
    }
    // sort
    if(state.sort === 'price-asc') list.sort((a,b)=>a.price-b.price);
    else if(state.sort === 'price-desc') list.sort((a,b)=>b.price-a.price);
    // else featured keep order
    state.filtered = list;
    renderProducts(list);
  }

  // Modal
  function openModal(id) {
    const p = state.products.find(x=>x.id===id);
    if(!p) return;
    modalTitle.textContent = p.name;
    modalDesc.textContent = p.desc;
    modalImage.src = p.image;
    modalImage.alt = p.name;
    modalPrice.textContent = formatPrice(p.price);
    modalQty.value = 1;
    modalAdd.dataset.id = p.id;
    modal.setAttribute("aria-hidden","false");
  }
  function closeModal(){ modal.setAttribute("aria-hidden","true"); }

  // Cart functions
  function addToCart(id, qty=1) {
    if(!state.cart[id]) state.cart[id] = 0;
    state.cart[id] += qty;
    saveCart();
    renderCart();
    updateCartCount();
  }
  function removeFromCart(id) {
    delete state.cart[id];
    saveCart();
    renderCart();
    updateCartCount();
  }
  function changeQty(id, qty) {
    if(qty <= 0) removeFromCart(id);
    else state.cart[id] = qty;
    saveCart();
    renderCart();
    updateCartCount();
  }
  function renderCart(){
    cartItemsEl.innerHTML = "";
    const ids = Object.keys(state.cart).map(k=>Number(k));
    if(ids.length === 0){
      cartItemsEl.innerHTML = "<p style='color:var(--muted)'>Your cart is empty.</p>";
      cartTotal.textContent = formatPrice(0);
      return;
    }
    let total = 0;
    ids.forEach(id => {
      const p = state.products.find(x=>x.id===id);
      const qty = state.cart[id];
      const line = p.price * qty;
      total += line;
      const item = document.createElement("div");
      item.className = "cart-item";
      item.innerHTML = `
        <img src="${p.image}" alt="${p.name}" />
        <div style="flex:1">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <strong>${p.name}</strong>
            <div>${formatPrice(line)}</div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;margin-top:8px">
            <input type="number" min="1" value="${qty}" style="width:64px;padding:6px;border-radius:8px" data-id="${id}" class="qty-input" />
            <button class="btn small remove" data-id="${id}" style="padding:6px 8px">Remove</button>
          </div>
        </div>
      `;
      cartItemsEl.appendChild(item);
    });
    cartTotal.textContent = formatPrice(total);
    // attach listeners for qty and remove
    qsa(".qty-input").forEach(inp => {
      inp.addEventListener("change", (e) => {
        const id = Number(e.target.dataset.id);
        const qty = Math.max(0, Number(e.target.value) || 0);
        changeQty(id, qty);
      });
    });
    qsa(".remove").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = Number(btn.dataset.id);
        removeFromCart(id);
      });
    });
  }

  function openCart(){ cartEl.classList.add("open"); cartEl.setAttribute("aria-hidden","false"); }
  function closeCart(){ cartEl.classList.remove("open"); cartEl.setAttribute("aria-hidden","true"); }

  function handleCheckout(){
    if(Object.keys(state.cart).length === 0){ alert("Your cart is empty."); return; }
    // Simple simulated checkout
    const total = Object.entries(state.cart).reduce((s,[id,qty])=>{
      const p = state.products.find(x=>x.id===Number(id)); return s + p.price*qty;
    }, 0);
    if(confirm(`Proceed to checkout? Total ${formatPrice(total)}`)){
      alert("Order placed! (Demo mode) — Thank you.");
      state.cart = {};
      saveCart();
      renderCart();
      updateCartCount();
      closeCart();
    }
  }

  // Persistence
  function saveCart(){ try { localStorage.setItem("shop_easy_cart_v1", JSON.stringify(state.cart)); } catch(e){ console.warn("Unable to save cart", e); } }
  function loadCart(){ try { return JSON.parse(localStorage.getItem("shop_easy_cart_v1") || "{}"); } catch(e){ return {}; } }

  function updateCartCount(){
    const count = Object.values(state.cart).reduce((s,v)=>s+v,0);
    cartCount.textContent = count;
  }

  // initial run
  init();

  // Expose some things for debugging
  window.__ShopEasy = { state };
})();
