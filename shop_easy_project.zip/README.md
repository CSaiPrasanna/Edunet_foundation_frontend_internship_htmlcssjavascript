# ShopEasy — E-Commerce Product Showcase

This is a polished front-end internship-ready project built with **HTML, CSS, and JavaScript** (no frameworks).  
It demonstrates a responsive product gallery, filtering, search, sorting, product modal, and a persistent cart using `localStorage`.

## Features
- Responsive product grid
- Category filters and search
- Sort by price
- Product detail modal with quantity selection
- Add to cart, change quantity, remove items
- Persistent cart using `localStorage`
- Checkout simulation
- Accessible elements with ARIA attributes

## Run locally
1. Unzip the project folder (or clone the repo).
2. Open `index.html` in your browser. (No server required)
3. For a better experience, serve with a simple HTTP server:
   - Python 3: `python -m http.server 8000` then open `http://localhost:8000`

## Deploy to GitHub Pages
1. Create a new GitHub repository (e.g., `shop-easy`).
2. Initialize git and push:
   ```bash
   git init
   git add .
   git commit -m "Initial commit — ShopEasy front-end"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
3. On GitHub, go to **Settings > Pages** and set source to `main` branch and `/ (root)` folder. Save.
4. Your site will be published at `https://<your-username>.github.io/<your-repo>/` (may take a minute).

## Customization ideas
- Add product images and more metadata (ratings, reviews).
- Integrate a backend (Firebase or Node + Express) for real products and authentication.
- Add animations with GSAP or lightweight libraries.
- Add unit tests and GitHub Actions for CI.

## Note
This project was created from the list of frontend problem statements you uploaded and recommended as a high-impact internship project (E-Commerce Product Showcase). fileciteturn0file0
